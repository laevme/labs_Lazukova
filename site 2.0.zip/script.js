(() => {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const skillsBtn = $('#toggleSkills');
  const skillsList = $('#skillsList');
  const hiddenSkills = skillsList ? $$('.skills__item--hidden', skillsList) : [];

  if (skillsBtn && skillsList && hiddenSkills.length) {
    const sync = (expanded) => {
      skillsBtn.setAttribute('aria-expanded', String(expanded));
      skillsBtn.textContent = expanded ? 'Свернуть' : 'Показать ещё';
      skillsList.classList.toggle('is-expanded', expanded);
    };

    skillsBtn.addEventListener('click', () => {
      const expanded = skillsBtn.getAttribute('aria-expanded') === 'true';
      sync(!expanded);
    });

    sync(false);
  }

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const header = $('.header');
  const headerHeight = () => (header ? header.offsetHeight : 0);

  $$('a[href^="#"]').forEach((link) => {
    link.addEventListener('click', (event) => {
      if (event.defaultPrevented) return;
      if (event.button !== 0) return;
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;

      const href = link.getAttribute('href');
      if (!href || href === '#') return;

      const target = document.getElementById(href.slice(1));
      if (!target) return;

      event.preventDefault();

      const top = target.getBoundingClientRect().top + window.scrollY - headerHeight();
      window.scrollTo({
        top,
        behavior: prefersReducedMotion.matches ? 'auto' : 'smooth',
      });

      if (history.replaceState) {
        history.replaceState(null, '', href);
      }

      if (!target.hasAttribute('tabindex')) {
        target.setAttribute('tabindex', '-1');
      }
      target.focus({ preventScroll: true });
    });
  });

  const yearEl = $('[data-year]');
  if (yearEl) {
    yearEl.textContent = String(new Date().getFullYear());
  }
})();